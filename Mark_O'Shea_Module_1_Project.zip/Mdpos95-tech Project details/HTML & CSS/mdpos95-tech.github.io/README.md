# mdpos95-tech.github.io

# Manchester United Fan HUB

My student software development project for module 1 web design.

Features: season tracker, club history, squad & player stats.
